<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Agro-Shop</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css"
        integrity="sha512-MV7K8+y+gLIBoVD59lQIYicR65iaqukzvf/nwasF0nqhPay5w/9lJmVM2hMDcnK1OnMGCdVK+iQrJ7lzPJQd1w=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="footer.css">

  <link rel="stylesheet" href="style.css">
  
  
  <style>
    body {
      font-family: 'Arial', sans-serif;
    }

    #agroshop-container {
      max-width: 1300px;
      margin: 50px auto;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 10px;
      text-align: center;
      background-color: light;
    }

    #quote {
      font-style: italic;
      margin-bottom: 20px;
    }

    .circular-image-container {
      display: inline-block;
      text-align: center;
      margin: 10px;
    }

    .circular-image {
      border-radius: 50%;
      width: 100px;
      height: 100px;
      object-fit: cover;
    }

  </style>
</head>
<body>
<header>
  <nav class="navbar navbar-expand-lg navbar-light bg-light ">
    <div class="container-fluid">
      <a class="navbar-brand" href="">
        <img src="logo2.png" alt="Company Logo" width="250" height="130" alt="">
      </a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ms-auto"> <li class="nav-item mx-3">
            <a class="nav-link" href="#">Home</a>
          </li>
          <li class="nav-item mx-3">
            <a class="nav-link" href="?page=#target_div">About Us</a>
          </li>
		  <li class="nav-item mx-3">
            <a class="nav-link" href="product.php">Products</a>
          </li>
          <li class="nav-item mx-3">
            <a class="nav-link" href="scheme.php">Schemes</a>
          </li>
          <li class="nav-item mx-3">
            <a class="nav-link" href="login.php">Login</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
 </header>
 
 <div class="container-fluid ">
    <div class="row mt-2">
        <img src="home.png" alt="Company Logo" height="700" alt="">
		<div class="text-center text-white pt-4">
          <button class="btn btn-primary mt-3">Get Started</button>
        </div>
	</div>
  </div>
  
  
  
  <div class="row mt-5">
      <div class="col-3">
	  <div class="circle">
        <div class="image-circle">
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxISEhUUEhIVEBMVGBIYFxgXExsYFRcSGBUXGBUSGBUYHiggGBolGxMVITEhKCkrLi4uFx8zODMtNygtLisBCgoKDg0OGxAQGyslHyYrLS0tNy01Ny0tLS0rLS8tLy8rLS4tLS0rLS0tLy0rLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIAKgBLAMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABgEDBAUHAgj/xABPEAACAQICBAcMBgUJCQEAAAAAAQIDEQQhBRIxUQYTQVJhcZEUFRciMlSBkpShsdEHU7PS0+MWIzWy4SRCQ3JzgoPB8DM0RGJkk6LC8Sb/xAAaAQEAAgMBAAAAAAAAAAAAAAAAAgMBBAUG/8QAOBEAAgECBAMFBgQFBQAAAAAAAAECAxEEEiExE0FRYXGBkbEFFCLB0eFScqHwFSMyM7IGQlNi8f/aAAwDAQACEQMRAD8A6IADommAAAAAAAAAAAAAVKAAAAAAAAAAAAAAAAAAAAAAAAqAUAAAAAAAAAAAAAAAAAAAAAAAAAAAALGPxkKFKdWrLVp04uUnuS6OV9ABXE1GrWPFOdSXkpy6o3+BGODXDKOkJ1YwoypRpajTlNOUlPWWcUrR8ne9pMMBpJRycVFWWcU82uV+Ojy+OxNSONlDiuMfh2dv9q8F4ndwlCDw8ZOCb1372Y8uNWbjJLpiyzLEyS2+42mI0rFxslrN8kk7Ncv9IyL8JdKdz4erX4tS1EnqJ6t7ySsnZ229JrxxVVV6cVWlJOUb6t7tc9i2VCDpybppWT5LoSGm7pPekVOVw+mBpJdwrJL/AIn8oeGF+Yr2n8o9eeesdUByvwwvzFe0/lDwwvzFe0/lAWOqA5VH6Y2/+B2f9T+UV8ML8xXtP5QuLM6oDlfhhfmK9p/KHhhfmK9p/KAsdUByvwwvzFe0/lDwwvzFe0/lAWOqA5X4YX5ivafyh4YX5ivafygLHVJSSV27JbW9ljV1dP0E7XculRy7WRPDcK5Y+ipcVxEdaSceM19a1rO+qstuVuQuVcK4vamnmmtjW9F8KSauzVq1nF2jyJhhNJ0qnkyz3PJmYQR0pU1Gd0m9i5bb+r4kw0XiNeCfQuxojUhl22LKVTOrPcywAVloAAAAAAAAAAAAAAAAAAAAAIp9Kn7Mr9dD7emSsin0qfsyv10Pt6YMrdGD9B2g6dTB1a2q+MdaVNtS2whCEoqzyydSWfSdI7wx/wCbtRDPoCrRjo6opSUf5TV2tL+ionRa9eDhJKcbuMkvGW22Wdzk4jD0ZTlKUE32rXQ36VapGKjGTSNFjtDSjHWgm0tqum+tWPFfgtTxNKVLEQm4SyklPVbSaazWe1Iu6GpShUvJqMbO/wCsj6FkyQ91U+fH1kaODw9KV6zp5XpZPlbmrpNX08u02cRWnH+Wp3XVc78ny0IN4ItE+b1faJ/fHgi0T5vV9on98nPdVPnx9ZHrjY85dqOpnfU0bEE8EWifN6vtE/vjwQ6J83qe0VPvk742O9do42O9dpnO+pnKQTwQ6J83qe0VPvjwRaJ83qe0VPvk1Tlf/aRtfZZbN17lKms34tWMVu1U/fczmfX1+hHwOVcKOA+isJKmlg51NdSeeKqRtZpcje81+C4I4Cqm4aNeqr5yx9SEctucmrkp+ka+vRvNT8WpsVrZx6SmBkuJptX4tKaaclKOsqEU3qcVPV8dVdts5PbrpG7GMeEpbt9r+TRpSnLiuN7Jd3zTIhi+DmjqctWejpRl04yq1ttdNZNXTWW5m+4PfR1ozE01PuSUL62SxNV7JNc5bivCR2hSUruptzmpeLa2zVi47IqzSzhLJWzk/ANvudWmovx9q2LXeW0xXilSUlo79X29WyVGcnUcW7q30Nd4ItF+bT9oqffKeCPRfm0/aKn3yc020/GqRa3WS/zL3Gx5y7UaTnLqbluw4c8PRw2KxOEorUjh6kdWLk5PUnThO+s22/GlL3G17uikoqGtFZ+Nt18ryyeSyStsst+ZEuFcr8I6iTylWoxdnti6FNNO21dHQTmhwd1ldVbZ28j+J1KNSLglI5lejLO3Hma3F4hVLOz1288sm9ia3dWzduUr0NQcKavuS7NvvLGB0DCm7tub6rLsNqkYqSTslsiVKm43ct2AAVlwAAAAAAAAAAAAAAAAAAAAAIp9Kf7Mr9dD7emSsin0p/syv10Pt6YsE9Tn3AZfyeX9rL92BIdVbiPcBf8Ad5f2sv3YEiN2nfKjnVbZ33lNVbhqrcVCVyV2RsgoX5Cc6Pp2p09+pD91ETo0tXrJnhLcUudqwtutq5+k83/qNZqVO/4n6Hd9h/DOdui9StijsirdixOVzx8sq5HpFdicrnmwBS4p8i25r9J6N45xetqat/5t73t0rca3CUK9OrKFGpOFmk5Rbje6vsT25knp0+VntRW5fx3+5HbwXtbEYek6e8bWimlZXd77XfPRu2t+WvLxXs6jWqKps7ptpvVJWtvpy1WunaaGfB2UnrSr3k9rcW32uWZstG6P4lW1tbbyW2u+9meWKk9xTivaWJrwyVpXV72tFa6rklybLKGBo0pZqcbO1t29PFvoKk9xbseoRu0ltZWlbWWtsvnt2cuw5mRS1fd6fXU372RyHSP7eX9vR+zgdk0d5PpfwRxzSVu/2Wzj6Nr7bcXDadj0d5PpfwR7/B/2Kf5Y/wCKPK4n+7LvfqZIBgYvS0YS1dVyttzt/wDS6pVhTV5OxXSpTqvLBXZngwVpelba+q2a/wAjMpVFJJxd09ghVhN2jJMTo1KavOLXej0CpQsKwAAAAAAAAAAAAAAAAADHxk2rWdv9Iu1cJhqq1JqpVUrXjKMJRbWfkt2ytf0FrG8n+txTD1km77Gmnbar8qPIY+vlxtSLenw7/kXb9T0ODhfDQa7f8me+8+Cpq0aTgnn4tOlZvld45N7DQ8KKFONGq6ask4WeqlLyo32dbJDi8VGWy2b1naOqr2tZK79L5THw0U5pNKSzyauthXDEWxVNReinHbnrtu1YnVp5qE8y1cZejOfwztymdRpqPWdgp4OlZfq4bF/MXyPGIpUoRcnThZf8q9C2HsJY9JXa07/seZjgXeyf6fc5NcleFklCH9WPwRvsFjKc5qMqMI32NRTz3PI2/Ew5sexHJxtSHtGnHhu1nzXy07zpYWnLBTedXuv31IPOdzzcnfEw5sexHmVOCTbjGy6Ecn+DS/5F5fc6P8RX4X5/Yg1y7Thys3tHSsHLOlFRbsnle29qxueJjzV2IqoezoVbuFRO3Y18ydXGShpKFvEh9xcmHEx5q7EeakIJNuKsk28lsRs/wl/j/T7lHv6/D+pC6lTcWrm/o6ZhKaTpRUW0r5XV9jasbziYc2PYjVo+z4105Qqp2/6terNipi3S0lBrxIdga0YvxuiztezI/jeElOFepCUJRUZNXVnlyStue1bcjqPEw5sexGp09waw+LhapC0l5NSFlOPU+VdDujr4XAUlHhYn4o8mrxkm+e7T00s0/FaGnUxrbzU1Z9uq9PmfP2LlrabhUjdwnWouMrNJrUina/Smdm0d5PpfwRyvTMoYXGVcM6l6lCUbSta94xnGSV3Z2kuo3+iuGFSmrTgqsd6erL5P3HpIYJRpxVF5opJLrord3ocuq3KTk+bOg01dmg4RU4KpeL8Z+Ut2St2otYbhph2/GjUp9cU1/wCLv7imlMVQxDUqNempS1U03qvl8a0rPJJdeRzvaGGrZV8LN/2dUhBvM7fQ12EvOThFOUvGy6L7b8hK9HYd06ai9ubfRfkLWitHU6MfE8Zy2y2t9nIZxHC4RUvie/oVYzGcb4I/0/r/AOFAAbpoAAAAAAAAAAAAAAAAAABxT2ojH0jYiVHR9apSk6c4ujaUcmr1oJ2fU2iTkU+lP9mV+uh9vTK5UoS1cU+9E41Jxsk2vEp9E8KuMwE6s6kqtWOIqRvJ3bgoUmo36G32nSsJgIRWcI3u87LYcu+hCtKOAqWk1/KKn2dI6F3VPnPtNFYKnCpKcUlf5dOm/I2XipuKi29P349nQ3xiYiWspRcJNW5LZ9Wfp9BHK3COEG1KrJNNp5S2r0GO+FdP66Xqy+Rse7Ta1V0UPEwXM3eCwKhLX1KkmvJTSVr3z25/xNtRqayu4uPQ/iQ39K6f10vVl8i/g9PKq3GFWTaV9jWWzlXSQhgVSjaEbLfmZljFUd5Su/AmBjTrPNcXJrZsVn7zQV9KunZ1Kkle9tr+BZ/SSH1svVl8iaoSMOvE2dHR0VNPVqWvdJpW9LvsNpCs27ako9Ltb4kX/SSH1svVl8izPhZT+ul6svkQpYFU7qnG1+8lUxilrKV/Impj152y1HNO97W7Hdmi7vqWvru230Gt/Sun9dL1ZfInGhJ7akZV4rfQ21LRUIzUtSpJLNRtHJ3yTd8zeUajkruLj1/HIhv6V0/rperL5D9K6f10vVl8iFL2eqSapxt5mZ41Td5yv5E3BEsHpt1U3CpKVrXya29aMnu2pz32knQktwq8XscV4WL/APST5f19D7GmS/GcDo1IueHkqM7vxWr0pehZw9GXQQrTk2+ELbd3x9D7Kmde0d5PpfwRt0pyp2yshJ80cl0jCtQm4VaerJWbs7qz2NNXyZawlXWjntRMOHmBcaka382doPomk7L0pe5kVUUtisdmlPPBSMozdFcIamDqRavKlLy4f+0d0vjsfR1DC4iFSEZwkpQkk4tcqZyjA6NdecvGUVSpznJy8nkUYvdfPsJD9G2Olr1aCvKmlrxfJCV0pR6ne/8Ade9mtiqad5LdbkZInYAOeRAAAAAAAAAAAAAAAAAABH+H2jK2JwNWjQpurVk6WrFNJvVqwlLNtLZFv0EgMzRT/Wx/vfusjJ2i2ZjujjvB7RvCLBUnSoYK0HJzesqcnrNRTz4zZaKNp3Xwo8yj6lP8U7eDV4z6I2MiPnyvo7hFNuUsFm23shtbu/6Qt96OEHmPuh+IfQ4LFiqiK/d6fQ+eO9HCDzH3Q/EMjA4XhHRlrQwKu1bOMHldP6zoO/gw8VUaszKw9NO6RwbGrhLVtr4JZXtaNNbf8Qxe93CLzP3U/wAU+gwYWImlZB0IN3aPnyWjeET24L3U/wAQt96OEHmPuh+IfQ4Je9VDHu1PocM4/hPa3cUbWt5ENn/dNX3o4QeY+6H4h9DgisROOxKVGEt0fPHejhB5j7ofiDvRwg8x90PxD6HBL3up1I+7U+iOCYGlwkopqGBXjWveMHs/xekyu6eE/mUfUh+KdxBB15N3ZNUopWSPnXC8FdLTx8MXisHKH6yE6kk4KKUUlfVU29kUdU0d5PpfwRKdMf7Cp/VkRbR3k+l/5FtKeYrqKxDfpJqucqVFO0Ypzl/Wfix7EpesReMbK3oJjwj0Txtec1Jq+qtl1lFLLcan9Hpc9er/ABOnRxmHhBRcrPue/kbMcHWcU1HfXdfU1/B/ROJxCqUqTUKblF1aj6F4sbbZNXbtsz6jo+gtC0sJT1Kau3nKT8qUt76Ny5DXcENDqhxstZyc3FNcicVfZv8AGJGU1q/Efw/0+RrVYuEnB8igAKCsAAAAAAA0PHz50u1jj586Xay3hMhnN8DQ8fPnS7WOPnzpdrHCYzm+BoePnzpdrHHz50u1jhMZzfA0PHz50u1jj586XaxwmM5vj1GTTusmiP8AHz50u1jj586XaxwWM5L46XnyqL7fmV78T5sfeQ/j586Xaxx8+dLtZD3WJPjMmHfifNj7x34nzY+8h/Hz50u1nmWLkts36zMe7RHGZMu/E+bH3l3D6SnKVtVe/YQR6QfOl2v5kr4NYepFSlUjJN2UU3fLa3712FValCEbk6c5Sdjd90S5vxHdMub8Smv0Ma/QzSNkr3TLm/Ed0S5vxKa/Qxr9DALeJxc4wk4xTaTed+Taa7C6enNX1YrtNtrdDOd4+FXC1JKanGm5SUJa2TSd16bMvoQjJ2ZVVbS0Jp34nzY+8d+J82PvIStIPnS7WXI4qT2TfrM2/dolHGkTLvxPmx9478T5sfeQ/j586Xaxx8+dLtZn3WP7uOMyS4/EzrLVk9WPKo8vW2YySityRo+PnzpdrK8dJ7ZN+lh0lTi30M071ZqPV2KSldt78zFxuI1Fl5T2fMyTAxkLy9CObGDcXPkeo4sOIqfNq/gjecHINUI3zbc2+vW/gbIjmFqSUElJpZ8vSy7x8+dLtZ0qdJuKfYeaxM/50/zS9TfA0PHz50u1jj586XayfCZRnN8DQ8fPnS7WOPnzpdrHCYzm+BoePnzpdrHHz50u1jhMZzwAC4gAAAAAAAAAAAAAAAC1UoJ57GXQAYrwz3mxWmMWv6V9kfkWARcIvdGU2ti936xn1r9WHyKd+8X9Y/Vh8i0CPCh0XkZzy6l3v3i/rH6sPkV794z6x+rD5FkDhQ6LyGeXUvd+sZ9a/Vh8jFx9atXSVWWuo3teys3t8lFwGVTguSGaXUxY4bpL1Oil1lwErEQADIAvZNg8YjZbeauLlanbqzo+zKeatme0U3+/1fgeKDcryfK3boS5DziVsLtONkluPOJWRmpTtQy9F92MPXzY3Pyk2vB7fIUHl/rcXSzhtnpLxZRd6ce4oxitiJ9/rr8wAC01QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAeHUW9FivTk3vRj1Yys7ZPkusjBkzVWjvPVeaTs8mug1+Drzg7zpRqtO6tUcY9TTi2+0uVK85tznbXlm7bE9yuVTp3qKT5X8/XzsbMKvDoygt5NeS/du5syePjv9xWUlJWTzezr5DCkrrd1bTxhadSDbhVqXfLaMmupuL1fRYsaumiiDyyTva2vkbR4eVNuMtq29iKmFhKEo8snm23J3lJvNt72ZpiEVCKiuRKtUdSpKb5sAAmVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFNVbimoty7AACuqtxUAAAAAAAAAAAAAA//2Q==" alt="Image 1 description" class="img-fluid rounded-circle">
          <br><br> 
		  <p class="image-text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Web Design</p>
		  <p class="ser">AgroShop has a clean and modern web design that is easy to navigate and user-friendly.
The website is responsive, so it looks great on all devices, from desktops to tablets to smartphones.
The website is visually appealing, with high-quality images and graphics.</p>
        </div>
		</div>
      </div>
      <div class="col-3">
		<div class="image-circle">
          <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTzFAsjDkViJ4E9JQBRjCIIvUdUrbYTR3MW8A&usqp=CAU" alt="Image 1 description" class="img-fluid rounded-circle">
          <br><br> 
		  <p class="image-text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Search Optimization</p>
		<p class="ser">AgroShop is optimized for search engines, so you can easily find us when you're looking for agricultural products online.
We use relevant keywords throughout our website and meta descriptions to help you find the products you need.</p>
		</div>
        </div>
      <div class="col-3">
		<div class="image-circle" id="target_div">
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAATgAAAChCAMAAABkv1NnAAACOlBMVEVgwa3////5vzYYMjpdwKzprohgwK1fwaxhxLBiu93qY1wZSEhZv6pDnIBRqZgoWFZIk4dklHfwQhxSpZYOHy4cPEFBjoETJTIWLzhcu6gcqco4gnCU08Zzf4JFno4AHyjgVRgvbGBwxrWMs6xXsqEAJzntRiGvYDuMv7DFzc6nnoLzjn1+y7v/xTbx9PT4vjeXyrzS2NjAPTCdgjixkDcuZGBAg3mq29HW7egmxu//ZgDkrok7RkWubU7stzZrrpiw3dSapagvkoLO4dwAAAD+ayHYowDQozX/viLnSwD/7Zb8zWUAO0rB5d0AABq9xsZ/lJmWu7X2l5EOIiZSn7uldGVYq8gAGjpKTTkfcGPFmBN+d1fWvlu3vXN7vpyRvpLmvEqlv4W+wHS/dk56rpfNvWS0gVxYd3ZvnJjjUQiWmX5jiY1OTzjWXSoAJDqqjG4AXmFcUCf7pi33tlv625eJdTSdRTF6Pza5fFTvcir72oXPZzXwkTYodnX4xmpyZjbt55/747Xzo0ktTFagoGT968dNZGz89OO+qF+Rm6DAsoBQQEE8TlPEWVGoU09dTU79wbvsdW/VjYfwWlX96uigmYqDm4mJYmE0Z3a5PjjxpZ/DKheIgpNBxdW3jYOekpQ4naZIjqW9bWT42dWzvJP/0qV8mm3pl4A+eIxMGypRu+Z1vMoACTqcmGqVXVLItpVud2uyhgVhODevn0NvmXWhjlR5hmoyJS5RimlLcVtHXEqRmVyqpFAyNTnOc6JSAAAX1klEQVR4nO2djWPT5p3HJevp4yexsNXakiVwbKwojHSyg0kkp22axDDi5MA4vBTCW9cWCqEFCruku4WlGcsIS5syKOVGy3V3HbTj6G5dr1s3rt3/dr/nkewkvORtWGmCvoAsK3Zsffi9PL/nefSI43z58uXLly9fvnz58uXL133C9A/buPv0wT3uvmD6hxw3vcHL9IW/H5rBC0+jmQHT2aFyn+DqE/fReceTjfE+4Zm7uGJnVcBcFSXng/Ply5cvX778XLhE+eB8+VoReqJcFSOMlvs7rEBhdPjIkZd9cosTIejHrwQO9776RLnYUhQMIixWzEuTLYkEe4Po5d4jvsk9XCgIfzDWQd3tukOJxCVJDr/Wi1Cwlx0hZFm/4/dOQSRiPUFlmuYMcIZAiKwFD7/yamfmZQh25NhRoh3zndYREhGFZiJCiMiEnA3isB2KRDT06uFXXkeAUkPH+/rWH/WtjgohE6BhMUikUEhKJPLdeabuPBxFRtQmmAOEQXgpOX6y7/hb69drfrTjEAZq1MKIEYqpauyEDvuISgxqgwkAmIBM0S2yZivq6nuDEO0kbJf7ey+vEHVRDC6JzO43BzpPqYIQtymTIOBRBssNSQh9ZiJf4vMie/2zfV2II6ePPuG9/RQbjWZ6Pt+4oy2zvXhGAHJRwhFxy2Ahyxf4QUIjoNjO8yb1TrC1twjpgs1yf/XlFHVScEjR7E5oZ891/uRfh1qGm97+qRoiZLQ/y/N8tsyXtSAAQ3mTc1sn/9Z39Pj69eufzBgHsGArmjR4iYnuBFHktszPNpwcGcnIm98WYtHEm80FMLh+YCfRBAG1Q9B5K3nj5Om+8xpzVOTSM/RlOg+vhfRSCYtc3gRzM7tNYuwYDmQA3IafDzFnVU9ER3N8tr+/APQGiZ7ID1qGWMF0jLzxBmGJ4seuFWrRJyTgieCG2RJ4KcLdCZGMDhQzgUAgs2HDhneGWsaaBDWkKWBs8JfnJ0OIaFYqdqIEqZflB+LWDujVf/lFpcMkvHwn450QzlMifEkEL0UkSpPCSCYw9M5PNmzYNjISAIuLEMXiJ3k+V7AOEBIV4ikry+tmPqFDrjUMRMmhV7dvr5LDxuq3OYR5R9lEtynis+d6RkaGhjovDPFD4Ky/HNre1hSLkrDdXy6MHtgS1ogSU0PArZ36asI+Md7QMG4pAPBXnU8WObHEl1104KZya+Yiz78zNHLxwsWRADjr9kzrDmjIacrZUQWoccSOqfaWdn4ruClJTuRy5VyukGuOGEnbIefWEIa02hsoYimXdcF1i+HYQAZ2LoyMALnezM9/Fih2nFXCwEACavBA7S1Jksouxg2iXgPf3AwbviGcVBxyovN74cVulbu851czYYOvSEfJ+JnWd2APvDXQC/khMLbDVsK064hI1PdINKZG29u1XVoeccbEJA9tlGZIuOVs/4Qm2b8Gcr8oueSgPVhqb2/P62Jwvq9Q63OsgYLY0BPdpVJ7qVQyEVYstakHfPUSOCtwaxNGFQksjRijsZ1QP2BNiCfD7e06r2dFEuGzk+PN2XI5Wx4v8NlRIim/7hzhecfERLNiyCW0+owO6QZOgDt168ynkKLITeeosw6NDGU6z4UUxSAEK6GdE82TEQhwVlwWFUXPJsolMUnTbDlX7u8v58Dw+AYNS8q78F5WxYqJqiHz2VU4rGNoCcQ53DCNWtJg6kwbWA2/vbd1x6iSxCRq7RSASzb7I41IsZSd1fPZTSaPubM5nnoqdVUACI8KIFYGt/JZkdobP0NZcbnP87FLTGDKDarUEoBDZqMSUYXeS5daigNnFckghpxqoDGsnOUnbBxJWZBClGgJKnwjBEQKvAMOiljqqwhHlXVdjQpk4exMcHxptZFDCR2JeVNEJrUKlEiEFUVoGsv0DtOkALFNSJWpP2bBpMpC2D5BGeSz5TAi4VB/f/8E/Dvxprtj0x5jQGdoWNzE87saK2rneTxfglhZQiaUTYmECIaX6BY12IOWRhoyq2yxpGAIqjoBXlpuzmZzfCqa7IL2mwGBD94bfcDi3oT2DLg7hp8aW3m+vMtVY5Y2EZf7XB+rMNSnOsRyZCZEZIyOjxKsKUo6FKFJAYp1Ia4KqVwul20ug79ORDRb0jiMadOWhGmMg8MMHP1XHiy1i7RwhR8nafXb7morayIu97k+TiEIcAjCD9KpQUijJCIRAs6qKEn6YxKxFFlNTfLlZsAysTMkEcMZtaHd6OF1tJOp0Fw40VBopvV/gyiG07KqhmyNbAFwx9ZVtHWVBTlwVCR2Q/SBFgk8GbS0cdqrEaVJgf48HDMkS1VlSJoNqVTE7krMlKmEsrn+8Ry1utxEfzZ7gKRjKeG994SUKm2ZnRtWmcUh8E+TtkagCuBwnoyGJNreIhorrjgiWbYEFpSanPpRKC2FxftYRBVo9jaXKbgC/A0RK/aP9+tBl4WUBUbWtcUVtbjEXC25FVY5BBM4SAeraGZl8IgTvJLxeCRJaJFl2KEQ+Kp8YnCjric2NsyWodgTPN+fbc5lJyEAanbsN7vrHQmpRnDjrRXxlWpilQhKhrweZAGOwWOCRq5tSCHVtm0oBBRFOnYsakDNFMTKztRM7TQMZV2ozPeXIcIVQoamyrt3u+TeV0PTvtpcKSZWiSAzOBk1X8kOQE2EKj6qJZVoNA52R4hp6oYmdouAFSv3WxyBhsmByMQOdSJ0QCN26rdXruy+6pB7LyVVuJV/NMG3ryJuAA4yA6K2FgRHdbhdr9csC1oUXFRWBUEVGgm8wMyzjhO8DiBAUzbrig4PYpaCFSWMiRZJfcDzV37ogLucOtDoVlspISVEV1HfnJigdoacjOo4Krl+rb4+GrIJ0ULADcilNAqVN3F7u4nWgfHcbc/mXPE6be1yGoi+NwzgPvyw4quXU7YiMW+dUqER7Yxprw5Rg6NOmsAsvXIut/qrhmxrzN5AtAcTdWehusjqFXDNjnJ8gvV5sAkkFJyV+mB3Ncj9KRU11gG4UkNqz6d7gVxEWyXokAnOl6cG53orJ16vp+CAXEig3OS0xTxMpBV9e1Z8wFV1U3fnx/17MEjCEOOmwb2XwqSLz0bTKfVGXd2+8T3qanFXZnDYMTiOGhz53TVwLBrbrybB4FTBloUwO1c63aE9wVFws6SLJp0FQbre/ugTHDQUWaiCu5yyiLh1a9iA5nMd1Z09q8VdMU0NIkeNzkkPv7tWz398tf4qWN37UGipEStXtpzxUhN3m/BSZbBxpjYhZrbk+s3/eO655z7BSjrVsXs3Sw7vC6pBwo0GkdU9+xi4ur3C6nBXsDQxAQUXYwbeCvZWf5X/+ArkRSB3NQqeaguq610IsQGXcHKWWDevfuyjDf/5HNN/KZGU8BI12Z+qMYlwkGmt+J5P6+ruOujAXdWV767MU6mxIVaxYuP31+qvXeFvXd3NA7hGC0KSYt9/mmSW6AH80s31257/HWBbu3atpFhqimZjVZCcki0GAe7urtu7HHbgrrHRlT5hWDRZTtUTDjxO2kLJXbv2w1u3rtVvGo0L0Lo15vkdkBRu/rb/+W3bnj9Kua1dm1RsKyQDORYbiRGHAHf3dm9vb+drjrtCdg2tbHdFfMnxVHr9P00N2CF3hf/ww2u7DsRkY/7TI8blj/Y+99zRbdu29b3IwH1iQI0mRdQz7N0kxAJcbwDU+8W0uyZXMjmxPU9TA6qkBg5jhZEDq9uopA8shNv1mycnaWx7ftv69X1vMnKYYC5pDQwXX0acG+C+YOAy796t+3QcMN5RhZiyoslBfY+wUzW4kz0Yufr6Ltuempi/5UC6bm7bdpSCu963HuSYHG0IBzKZ3iOYSHHagqu7e5hOfAq0fPHpHnXPXgCnyiusE+l+QUMEjI2bBocYOSMtW+VyZF5w2pafQXBjWeE0cDv5EiMXBJ9/BTgddgIcUwubMlY8A4m6bu8eIb4Aa/4+i+bSSk5lB/DtjYry+y4rFlLkBYQ4suU8gNtHaX1KTa7vUwcckb6joFBIVd0W3K7DnZnezICqCnV1qhBf6XNx2HAD7f1NOJ6Dbl/4TFOMKKQ9Z6BmHjFw25yk8NJJMLnzdWvXXiYcSX6eybQU78XVO3Wu7t6tu32uSQBHHVfj1grn5uaF6RBnPPvUUzqnKYMaQdoC3k+S56eTAg1y63n+1s2XCGconWNj55pU4caNPeM3XHo3UsKeO7QhJ6/4Wf0UnJ4Iuh0jwIGBQzqFtpCxY5I8erKaFN7sO9n3B6hef3+zixBrrLNTcALcnTv7GDoIbZApVkGA4xg4qDSdAS5uGpy50LEBklROTieFW3+4wur+m+8T++zrENDcEnXvDfqXmVpdncAqsZUuaMbR8BbUHVQMHBaRLi5wShY2lEMnq0mh0mFy5eZv7eS3w020BeeQu1O3bxxcFUCOq+qKD3Cc0xrJTydVBu7YbbzpGL6tLwgdiW45T03uPHBrp9AuXLh4iX//v7sM60zqRiUx1N3ZS+HV7WNWV9tT8kR0zoPIWiPOtRwM3FNPvUD/vrCwkRWsPM2iHO+OZ22HojQzXHzltdaxU19AKnU7RYDhjX11ToCr5Rl5JAecWG2NuOCYXlhgnDOU430nT75QcdMWaOaO7S9mqHoDLa+/dvv2LgB4o+4uNTlBja/oUqsiRK91q4JDaCngID8cevHmBxVwdMrwqT+2sQqL1ae9VJ1t//Pu7UNfjO8/sxoC3H3g0LHGpYDjcFLZ8qebtxxuH1NiLcUqtwq+4VOB3kxvT8/BI9P9eCtY0+CAkv7ZZ18uBRxHwOg2f0Sx3fro9P3IXDX9sQjbnp6e74yobVkRa2VHupkxDimfffbUl0sBB7W+8mfqrB/c3Hz+EeCKbQEGrk2AQlVV1djKHrMJ6gmRNkcoOE15+qmZWgw4ElYu37yyGfTzh3Oj10qAC/e0qfcURRUiVnqF11zQjqN95yzGhWeTWww4jpPszUy/fBQ41h3XI3z1sqYoUjK5kEL4n1DN/1vEbtZxzsouMJunX1giOAzOysAV5wR3sKknyObdkRqfWc3BsVrVRIiVXGSWzS2wAeyKRJW3N29+u6mTEdo+sr0lQFvCM301kwkMj/UgQ6mxtVF5AY4V+Jh1K80it3FxkwCxYm/+X7XJYTSUzWWzly5eHBravp0Sa+ksFtvahsdkWYjFYh4Mq9b8Eyr9cQ64meS+XOxcNkMRBLWD2VjvxclCobkwkWsuNxcm/3yqQz2zn0pVB85FrJgHeaHmqwHQMXzWA5x3a66w5IK7vdj/NExnWJ9yrOvZiRNTU0IqtRPsK6XKU1PDrW3F1s7WUz1fJ9OyBw2RmoNj7ZEExLnKbEkS6WD6R8diOxuJlAaLG+hoAuuKpVIpWZ6a6G9oaCjnys3XaeXa1nKuteeIFvGg6ArWfv0JJzuIeta9AsGI0Alx6lQ5Hl4sOCumqkJHxxhY1+RUuVAGd80VGgr04ulnOyHEjY2pAx1C3Isq3wNwzlwl0VlxhCbHCJ32kSrwE4sER6J2xFZez7RS4yrL5XKhoX+y0DAxNSGnYmCE8sDAKbn1q3t23IPc4InF6UFxejK4C04QGlKLtThDssPhrzuHafacUGVw1pgwNTHV0NDfkBtugdxaPDfc09NlxzxojdQ+xjm1A5v+wFQFpy7eVcODsdgf9zcJA+cOTUw0FApTzc3lQn8ZEitPe5kybfu/6ulBnuQG5AE4am64esFLFZywaHDItC27M0Bddai/H1ojcjlXAAG9Sw64pp6eg57kBvgutf8MMa8TMY8q093CVXDGA/Pg5tHGdFLJQIwL9F7op824FNhaodyQay5cZOCgbOj52pC96BbxAhxnNEajXdGKlJALTpWiszRf/5loGnb4Lw64i+CohXKqUGbgyoULrRRcB3jqd8lH1w2PsV3sBTiSjsXjqXhVakXxWZpvLDSo64Yd/dwBd2kyC0XDOIBraAZw5SEKrnP/wZ6eI3bMi0F8L8CBb8qheSXPN0sGm5xhJ3/FwGW2/3XowsVL5SyfpcvflHMj9GDbGQD36mjIiw5MlKj5R0BQi69b8/Q8WpOex+Jov5Rh298Wi8PFIt0cPHiwrVj89btfXs/lcofpwVMDbV999ZeQJ4M1Ys3BEQburWc2VPTMQ/XigbnBsW4pw443PSB2haGzK8A/j0YHaw5OU1xwP6xow8M0HzinO8+wRl8JBFoDLS3Opq0z0BLobHOeB9oG2sBVldhiWzlLUs3BYYOB++YH03qxqhkHD80JzuEGFjfaGciwBEo3FBykhDbneWasFcAdVOJe1A0exDgH3Jo1myoKHwdk33wDm0PTB9fMGeOQezEXxLjMo8E1FQFc0ZvcAIVkrT+hAm5jRWtOP7PhmUPHYfODNVRbtrCHOcCJlauqDfveo8EV1QyA+9qTusFLcNPGdRpi2qHjsGHg6KoXc4KjM4jdhplhf/tocMNjFNx3O7yZOSIui8U988xbx2FDwR34W1z92xzgEDan164x7L9mMk630oPgOooU3LdnvFlutObgtMYHwB0C/f3vsPmGGlwcitZHgQsCNhNPD00YSqyp49xAK7TfhumgVrETELrgOvcDyIM9nzd5s7iS2F3jD8DaA+BKlRV9uik4dRpcdY4mxqIILor0hDmrfDJsy05bodCOHU1N+5s6Bk6NUYZtrNe87VyGgrvnTW6oPTgu6IKrXrbb1V7Z20pdFUrXCjiwLuwsrt/eboKt0eHYWb/LSEfStmJJUjJ5YuPf7937v1OnBmT1zP6mAdgZayu2HuyZMzc8xhq29uC4ucGtgzJWrlicruv0JiKm2c1nTcrwvl9l2JGQEIfKN5KesCVJGlWkp//y+TfffvvX1lNNYwNq05km1aNp02Kp5h/hgusCRelmzSxwVbEYhxyJidLDllhly1glFQXcdSKkxtVQyAIDtEclSZEi8ue/+m64rfXMXHXD47Q4z8CxeJamD11VhacD3+zkgB8xVo2xYYSjSaWbLo1jA8CIrKoCGGA6ZCWTYIHrvKkbPAYXOcAeq7S61jwK3Jy/j6AS1hhAetVq0qp071EPjniUG7wFt+ZAiIGrNIU3di2w5JolhEuY3qrA6W7XJGeY1l2/JJ5ejeAsS/7nLQ7pJXfNWkI0yZLjcXBVKx2JO+MYXl1SI7bX/CNmWBwLcQ+zuIWDE81utr40pRaJx+Ihy6azCCXFpou/eHcNl7fg5tLCwIkJOrRNCKbU1EhaSYY1TF02qjiDQF4tyuoNOHdYa24twMsQW9CFkKjFqElRA1dGFelKaSFVnf+K68ckj8DNFlB67x90fFAVZhycH5yY6MaIGKNCLA62Fr6v4aEpSiQeIavc4k6/vWiLE9ndWrRILBZKK9GHrCqCJSUS8+qymuV1VVWdsfcAuFk3aEAon0eIYFm17KTBPWxqNHbJeXJRjSfgLHm2KrTkqeljsCvR28IFqeBBhEqfr8zUgWf5bh2imxRS5eijuTjkLLo+cK3PygtwUWW2JHe2kqwM7mqsHmzclKf3CaV3WIUqn67/m+WdHnNRxBQbZjcVCUXUOYoqIBeKC2lZqP1VCNlafwLH1micKclpq6ohKJz0fN6sHEcI084RKp12jWDa0AUrTHTnnbv8amo6JCfnHHDGkgzOHK39vBsvwM1UEJyvCo5Qp0QJYIed9c+4oNs9wlyU3mMPJ/LQAnErBSUGnmhbc5Wj9DUyvKbmzRKvwbHlkqvgWBwXRc6kdwTVnR4l57Y99H6hOr1RqImqKQLb8bRth+W5LE6z47ZthWs/DcJbcCRqgyx3vpJMn9h0bAU4cSbFlHeXN2d3p6WrgM3sy8SKFbeiVmyu6WCaYqlpI72z5iM23oLDUhpkubLpk9FKx6Pjo879t90e9Pv6MklSsoWYPOfMaCJJUFV4UOqLfK0/YabCUvI+SQ8U5bQ58oi34yRdQnluJpqkPLgCYuX9i//Gj5S34O5bw3HxTVVt3vvlYc4wvOgE9hjc6hHywS1NPrilKYh9cEuSD26J8sEtUYj44JYkpPvgliQf3BLlg1uifHBLFDJ9cEtS0Afny2Otrvvf+vrea4UvTufLly9fvnz58uXLl69HCrP2PsYcdnfdY3i6DsAzX+2rIkxFieDqLnbFTT+ZhvnwXfablvdEfPnytWD9Pxd+mbMCrKUYAAAAAElFTkSuQmCC" alt="Image 1 description" class="img-fluid rounded-circle">
          <br><br> 
		  <p class="image-text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Online Shop</p>
		<p class="ser">AgroShop offers a wide variety of agricultural products for sale online.
You can find everything you need to grow your own food, from seeds and fertilizers to tools and equipment.
We also offer a variety of processed agricultural products, such as jams, jellies, and honey.
</p>
		</div>
        </div>
      <div class="col-3">
		<div class="image-circle">
          <img src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBISERgRERESEREREhEREhISEhESERIRGBgZGhgYGxgbIS4mGyIqHxgZJTclLC4xNDQ0GyM6TToyPi0zNDEBCwsLEA8QHRISGzMjISM2MzEzMzMzMTMxMzQxMTMzOTM0MTMzPjMzMTMzMzMzMTEzMzEzMTM1MzExMzMxMTMzM//AABEIAJ8BPgMBIgACEQEDEQH/xAAcAAACAgMBAQAAAAAAAAAAAAADBAIFAQYHAAj/xABEEAACAQMDAgQEAwUDCAsAAAABAgMABBESITEFQRMiUWEGMnGBFEKhByNSkbEzwfAkU2JygqKy0RUXJURUY3STs9Lh/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAECBAMF/8QAKhEBAQACAQQBAwMEAwAAAAAAAAECEQMEEiExUUFhgSIycTORscEFExT/2gAMAwEAAhEDEQA/ACgVkCvAVMCtTIxipha8BUhSDKLRRUFqYFIxFoqChJRkoUKgoyihoKMgpCCItMItDRaYRaSomi0dFqKLRVWpUyooirXlWiKtIaRC1MLUgtSC0GhprOmsTSpGup2CqM7kgds4HqdqWiuXdtI0A6QwBBKtsCVDhuQGXJ04822cGgGdNY00h1zq/wCGtWuhH4mnR5GljiGWYL5nY4XB+tVvw38WpeP4MkJtpihkjXxEmjlQHBMci7MR3H19Dg1fYbAVqBWjkUutxGwysiMAcEhlIBoCJFDZaPsdwQR7b1BloIu60BlpthQnWmVKOtAdabdaC604VJSJSzrTrrSzrVJKOtCZKacUJlplYWxWCtGIqOKey0FpqJWimsEUFoErWCtGIqJFMaQWiKKGooi0jSxXgKyBWQKRsrRAKiBRFFAeUUdKgooqLQYyCmEFBQUygqacFjWuZ3dnP1lrmZ7xbaytJXjWNlZowiDJdgCBnGDk559BXUIxXO+o2HVOmSTN0+IXFrcyGYp4XjNGzcqUG5G+M7jAHepyXih020uOiT23+Vi5s76UQsqhgi6tOl1ySPzZyOQPcV1CS9ijlSF5FWWbX4cZzqfQMtj6Cud9G6f1TqdxBP1OMQW1o/jIhjMTyybEDQTkAFRknG2R322T40+HZ7yS2MLKixvIssmvTIkcmgMy+uFDbZ7iliqrzpfWre5MngyCQW7aJHAITOM5V+GHO4/5Zouq/EUhbTEWRSMqEC+Iy/xMzbID271et0qOKya2t00IkbKiryxxnc9yx5PfNaPIykajqVkQ+ZQDqRQSAynGcDPcVo4sZZbrcjJ1HJlLJPG0T1BmOS0hY8fvNb5Of4seh79qsLHrE6eaOVnUHzo+W0n0ZTuv1B39arvwQByskexyCUYD8258+3zH1/pUo0ChFypkBkMjA5ZyYjvwNgcjgdq73kxs1PP48M2rPO9flv8A02+FwFmjUakDo6MxBUtpOQcHI8v6+2KI8LIilyg8OUv5pCihSGAy4QZOW7jfJBzneo+B0bErfkJjA5xqGon9CP0q0604DDUyhVCaQxYKXdihJKjO3lBP8LuO9Y+XGY53GN/DlcsJb7CvbVJ4JIP3aPPrMQlg1okgUaWCSKBJgrr4qp6H8Fw2jLcyya5Yj4uY1WGFHMWiRgi9mG544G1WfVJYfwpijmQsuh00yJqBEi+YAHszDjA3AG21WF67NaMzDS7W7Mw7BimSP51zuVkrthjMspFbL8QWzKVIchgynCjcEYzua1tbGy/zt0uP4VjXvkcDG3+OTlR3CqWOcAcAZJPAA9ya9bCSRQ4RArAHBkOoD0ICYB9smsH/AKs5N+Hrc3TdNxT9VsX/AEme1ttYjed1kYHzICFxnAGPrj7CrBetQMQNTDJx5kIA+taDdDLprXOXfUx38PGcKP4Bp/MMcc55fsySqEknLEKTyyB/Ic99sb96d6jOavjyjHpOLL58/f7Nv63fC2tZbgrq8GJ5AvGoqNh9ziuRx2lpfRJddU6nKlxOk9wIgpKJCjunlGCB/ZtgDc+hrsnVbFLmCS3fIWaNo2I5AYEZHuOftXL4J7/pcS2UnR1vRGJo47lEaRZIpHLFfKrYBLHynH0rc8sz8I9UaC/PThcvdW0kCT2ksmdahoxJp33wVJ27aRsMmt7cVqXwx0W4kvW6pdwLasY0it7YHLIoQJqYfl8owBtydhgZ3BxVYppSQUs6024pdxVRFKstCcUw4oLCqIBhUMUZhUCKCCIrGKJivYoAemo4opFRIpgshoy0JBRVpBMVICsCpCgMgVNawKkooCaUZaGooqCgx0FC6r1OO0gaeYnSgGyjJdicKoHqTRoxWr/tPsnk6eGQFhDMksgHOjS6lvtqH2ye1RV4+ydl8Y9SnkX8La2kweOSf8OkjPcLAmkFmbUACSSAoGrY+XjO7/CvXo7+38ZFZHViksTbtHIOVz3Hof6HIGpz3kds0l/BcWkfT4+my2/TUgdFufHkVNigGrXrUlieMZ/ir37Hop3W6vJizfipkIZhjxJFLtI/py+MjuCO1RLV2R0pRRlFLzyeHGz/AMCM2/fAqFtdl1BBjXLunmYglwxAAX3GDyeaZH1FUXVfhtXYvCwR2OSp+Vj3I9DT0t+yyeHhNRXsc4fS7Dkg/lG2nG/PatGvLu5jnkkaYvEZQh8RUbwnKqy44JUhwAAwwRtnIFRee8d8e3PlmOU1Zs7J8N3K/wDd4291WE/1pa96W1sNLR6C5LZUhlbjbPIxgeXgf03X4YvZJoNciacMVRsk60wCGwQCOeDvtT3UbOOZDHJjBwRuAynsRWrDqt2Wya+zjelll7bfPyq8OkCyWrLHEIlZEYAoznJPiEjUB8o1A7ZYkEbgkVy0sDT5jdoZJGjeHJV4kbzLjJyWUEEZIyAeQKY6NGYovBkdGCMyoQRhozuuR2O5GPavW1wEZ2mliRAAqAOqx6R6KTtgY323YjcBTXDL3fq04ftnjSjHUIpZ0tlljkUyoulWRitvGZ5Dnc+XyRgnbZl+pdvesLKksaqwVo5fDl/LJpUl8AjsQw+q9gQSrZdPhiuY7j8Rb/uoHiVRKhaUnSFY5xjbI78j03b6bBaxL57iEs0ZRoxNH4ahgNSrnzY2HJwOwUYAnKSzTphlrKX4aZKmpSBsdipPAZSGX9QKBGZFy2JFZyWcBFkj1HkqquCP7++9bnD0K0mJMFzrAwSI5I5AoPG4/vqN78OQxRtI0smFUn8gyew47nArBeDKTzI9jPn4OX63d8ettOdHY7Bn1jDvKiKI/wDSQHjuMY9N+cuo2XB/0l/rRbGyedtKLn1J+VR6k1b9P6favL4azNJJHkvoGIyy6dShuNtS8f3HEcfFll5k9Kt4en93zf7ri56hHGwRm85/LkDG2d2YhRz3OamjhlDjhgCM879j70O76cH3IVxq16X1KwO3DruBsNiDwPSp2lt4cYTjGo41FsamLYDHcgZxn2r1Hh1Q/E/XhaKqIglnlDsiM4jjSOMZeR3Pyoo+5OAK1Cz+NLxmZmFjdRxjXIlq0wmVO7KX8rEDPl2JOwo/7RrJ/wAUshICXFhPZxlmCxi5yzqpY7KWB2yRkrVBNM6uJJPFjiWUzkTPbiO1jWNx4EIVyXBZlAAC/Im2dwbGnTLa5SaNJY21JIiurYIyrDI27fSouKrPg2xeDp0EcoIcIzMrAhl1uzhSDwQGAxVs4qo50s4oDCmHFAaqhBMKGRRWFDIpkhivYrNeoJjFYIqVepgigoq0NaItIhBU1FQSiCg2QKItQFEWgCKKKgoSijqKRjRimkAxvjGN88Y96XjFAnnCgSOuseKUAIyI1UsGfHr5Sc+n6zVwmPgbpbv4v4WMnOcI8gjz/qq2n7YraraFI0WONFREAVERQqqo4AA2Aquikjk1NFtImfylCxU4KN6jOxB4yD6GraFgQCOCAR9DUmwbqNWKs6gqMsDwAfU8Z3G3O9KzJHJIqJcorkyER6vEOsMjNgBh8rLkocjcbCsXnS0cSa5WSKQh3XyBVcIqBgxGwwq7eo+1F6V06NG8WN5Gz4i4fVtq8MHZhkY8JdvegzVzcpbgu7MzSHYZBY44AzhVUZ5OBvucnesSKznk1m1Z5XwrI4DKo0t52AYoBjyswyfMoPIFH60xWWKRU8Qxh9SYzhXZFUn6sMAAEkgEA6SKnah2nNzIvgokZjAbILZKnOCAe2+QM+XHy5M5dut09b8JdbV4rV3iYxMkbJGkSoEQvhQ2CNypORwPY1rXULS3S5EMFlaTSLpUyXEfiTyPz85BZmxuWY+pJ2rbuvqTayAHBKDf0GoZ/Stf8L/tXHGtnIPoTFKvH0X9a6Ya1XHmt8SeN0H8LJjUthZBechbPAA+uKEX0nLQ9PQ+62hP8w1VttBGuW0SAawRoijByAy8a9t2b+nrktvb2433XyFV1QwBlAYsOZtzk549qvux+nn8OMsvvKz8rA9R0jIezX2UIg/mNj/Ogp1+Q/2clr5FY7OsmFAyTpXcAcnApZLGFw2kvsG4jTB4zjEp41ZpiO0hSOSQIygW9wcsGwf3TAgapGIPfJB4IyM0f9nHvtl3fjQnHlf1buvnZqHqLSRLIyIk9vf2sPiRZ0lZLhIZMZ30srsMfQ+lbJ1iz8VFUuI4tQaQ9zjGlRnYb/0Fah0tWjt3ZgG1X1iSORkXNsmf5qxrbr90tY8oqh2bSmrU2XOTuc6j379xXHm7ZvfiNPTZ5alnuKua2kfEFrHotfMJJGOgu4Yqy4PnIGk9sNkD5eWLa2jt5RFFEHmkiZ5JThBoRlVVJwTuX2G/DEknliwvpGmMMvhFtBcGMOuANOD5icgksO2NHfO0Otkq0TR7TtIkSPvtG7p4gI4byKWAPdBxUY5Sydvr7OuW7d5ezEszIpeRAqqpZmEi6VUDJJLY2oFnepNEswDIjjIEimNhvgZDYI+++9D6rqaErkPHIyIZEBYhCwBJVc5x6jYnsBS/gsXCuI0ZwulZI1kLoJPFdVw+xUFRkjAIDb8V0QavbVJUaOVEkRhhlZQysPcGtftPg/p1u/ixWqK4OoMxd9J9VDkhfqK2dxVbc4JdnUukQ/swpcswXWToHzHBUAeuaCQZg26kMPUEGgOKpOg373Nu92wKuskwjHgtCFjRmATUd5AQBqPYkjYrtePVQqXcUBhTD0BqqJCYUMiitUCKYCxXsVLFeoJGsVmvUBXpRVNLoaYWhIy1MUJDRVoCa0VRQ1oq0GktHSgqKOtIx46HNahhobX4ZcuDHgspIOpSMEkEsTkevbG5Uor3Mca6pHSNc41SOqLnnGSfY/yqauIwW/IjMnnBV3ddAUNjUQCoJYgDGNh+htxkKdIBIB0rnSCcbDPagQMGAZSGDAEEEEEHggjmmIHDAMpDKeCpBB+hFSan/FtJpLp4bpJ5FIKu0b53VD5gchBqXfduN6tOm27CR3dGTIAGWDE5JyC+cuAFUgnjUQMYxS8/S2eYurBVbQxJBZgyZ2UbDG4O5O4GxApPq10sRd3JwpPGSTk4AH1JA+9Zeq6m8MnbN23Xw78XHM97utLaCzYStLKVwrMyYJPOQGORtpTCge7nk5oZnM0yj8gbIH03ya1mHrYZgHVo1I5kIXjScc+jZ+xppeowkgLLGSeNMiEk+wBrzOq6jnyuM7NTxbJff5auHj45L+rz/hs3xAxWzmZeVidh9hmqS4df+lEHcFSfo0dwBv8AVTVtHD4tk8W/nSVPU754z9a13rUci3P4qFJLhD4bRGEIzRuviaiysQCpEhHOdj3Fe30uc5MJl63HmdVjcbr4quuYY0YuxkBONOlxqdSAxxtsNR49a84TAB8RdRB38NgCdiSAP19u9Hl6tfH5YmQdsWmhgvt+/wAfpRYTducrDcMT/wCX05QPfzOxrpOLW9MOpbrYdjC4fUocox8NSQcs5dDgDtsjH7GrDqMbJE5KMo8K5xlSAT+HlOKTm6hMNmePUhKt4snTQU7EHB29KrOo9WkKOgms1Lo0ba7mxBCsMHjc8+tZ70kvJOSZevo2Yc3ZhcO23f1N2Sf5ACSfNe2Lk84xfwr/AEFbL1tVkuY45E1R6JjuTp1jRpBHB8rSc+la50bDQi3jeOSWS6gfw4JBOIYlmSRnd1GBhUY9ssQOTW83vTopiC65ZM6GBKsudjgjcUuu47yTWN8unS3tnlqEEaJ4cqp+Hf8AGQxhVV4w6tKE+Q+qOcn68bitj66qmMZRJGJZAHZEcKylHKFmGDhsZzkBjzwSw9Ft0cSBCzr8rO7yFfpqJxVN8V9OebDFNaIyIhCNIURgdb6U83zMhwO0PuK5dJw5ceNmV93f8O/JlMr4U8VzJBreWT8M628blAqI00hdwAqMDpjBVgcKDy/5zm8+H+oyTKVcrII1QeMCv7wlRkHT5S4YOG04GcYGDVXcdVVSmiRWjZmXQzK8UQR0WEMzA6QxRix+ZRIvGFq96FbhLdWHMoWVtiBlkUbAksNgNmZiOMmtlcTbikZ42Da0wSQFZWJCsBnByAcEZPbf+RBup3XhR6whkYvHGiAhdTu6ooLdhlhk74AOx4qguOtTqzJ4MbmP+0MP4yZI2xkqWSDBYfwjfjYZoAlv08RxiBF8OEM7MC5d21uzuucbAsx39NtuQd6BZ9RaRgjrH54zNFJDI0kckYKhtyilSC67b888gMPVRNLvQWoz0FqpITCoNRGqDUwgajUjUTQVYNRJrJqJNAVsdMLS8dMIaEirRVoK0UGgCrRloCUdaDEUUVaGtFWkodKlc2qyxlHyAcFWGNSOpBR1zwQQCPpUUqVxA0iaBI0YYgOybSGPuqtnyE8ahuBnGDgiaqKPp9wWb8K0qLCZTHP4WVCyklQiMPkilZW3ySrrJGDkjTu0KBQFUBVUAKoAAAGwAA4FUl30dJERI9EWhPCUeHqj8EgBoyisp07AjBBBVSDtvadNikSJElk8aRFCvJo8PxCPzFcnBPf39OKlR9a1T4pXIYesif8AEp/ura1qh6zbLI7I2cZQ7eoCkfrXm/8AI3txxv3/ANNXSy22T4VEFlFMokYMXwEYrJImQvGytjjFKX9kkUsATXpkd1YNJJIMqhdTh2OD5CNvWrJOmhTlWdT3IL7/AF33oxsMsrNqYoSy6tZ0tgqSATjhiOO5ryePmuGW5lbPjy2Z8cymu2b+fC8tb0RQA6cszMAM6RtySewH3PtQL29iEE0rQRiRI5JFyoYO2MA+ZQdyVG43yKYtrHxIAMlWDMQSNsHGRjuDihdSjWCBFJjTXPDrdlVY1RH8VyxO2NCPue5Fe90n9HH+GDm/ff5Y/B5YRJskKJGCeFVVAryfvQvhSGG2RhrnyqvcgHOhGPyoTy43I+XYhqjdyK0BldWFqTnw2BDXOojzOuMhOTp/MOdvKdD6r11bsuJdUahv3bFWKpjgYI2zg1ruVs1PTLx8UxtyvuulWmkeKIf3gR0CR6FjjjAjTyIwXDDk8nBYjIxskfiKHXpmieNhsdahtJ+2/wB65pbdZa10NC2lhh2wV0MmSMED5gdz32966jdWEN9Asq4BdFdJAMkAjOD6jfiuHJMtbxq8t6/Snc9ft0TWrCQnYKmNRPuOw9zVFP8AGjK3yxKOwZmLY98VrfVomiJiZgra/DZgcqowSTn6ClrjVEuhMYwWUjGrAxnI04J3/lmsd5s79nO5Z9u9fz9nRekfEEdwQuNDngagytjnS3r7VpU/xTcQdSSGWWfxGv2hlt2SIWq2UjaYHQhdWrDI2rPZgfSq2ydlkyupVcnSNlZWXOH2xudJ4G2kd+eiSdJt76O3nuIw0sXhSpIpKurghsahypYfKdq08HLu2ZeVY23xfZ+7sY5f7RAxGoAglWAZSrDIwcEE/wCAKIwozUJq0Oip658if+rtP/mStNvLeWSMJCumSH8QrSLo1QXbSli76nXw1IYSagrFlb3Abeeo28cqeHJw7KVwSrB0IdGUjhlKhge2Kob74ZSZ1eaaSVl+V5IOnu477M0GaaSfTpQ8kDhETXb3znwxhHLTwkyKP4XJLj2erWSowWAjcu0kkzldAeQx+WPOdKqiqoyQCdsnA32GMyVUTQHNBaiOaCxqkoNUGNSY0JjTDxNYr1RoJg1A1M1A0AgtGSgrRVNBDLRBQUNFU0AZKMtAU0VTQBlNGWllNGQ0qo0hpmM0ohpmM1NVDsZo4fB34wTn6c0tGaZT25HHp96mqibzYjLoviEIXVRnz7ZA47/SkB1a416Vs2ZSyIHLyIPO2nODHsMYYnsGA5DAH6eXVjGVOgZ0HGVHtnt/+VZoaXuKs1VJb9UupdOLdrbLxnEkcsjaC4DI2AFUhSSTqI4xnfFo/UMMQFBw+ggvpcb4yFI82+MYPccU4KjJCrHJG/GoEq2PTUN8e1LUMaNwyhhwwBH0NLXVikrI0mo+E+tV1EIX7FgPmxyAds4OMgYYQAAAAAAYAGwAHaiCkGv/ABsr/hC8Zw0bo/Ge+nj/AGq5PNdFg0hALjMcaaWzI+NfmA+bJBHvXa+rNF4LLOyJG6shLkY3GNh3NcE61cRq5UMqszkkF845B0nGnGCcfX1qsYNoXw0yOA3l8ug7MV38w+2/bFd4+HLcx2cMZGCsSZHoSM4/WuFfDapNeQRuy4aVFOphgqDvv/jNfRNGRRofxn0tg5lX5ZMEMeEkC4wfYgfqa1osWwJEYaNJAClwXH5gQD9u/tXW5oVdSrqGU8ggEH7VTSfC9uTka0H8Ktt/vAmsPJ09t3i554W719WgWfTDLOrIrByWCqTyWGC7egAzXU7aERxrGvyoqqPUgDGaFZdNigGI0CkjBY7s31J/pxTJrtxcVx82+Tww7Yiar7u+WN0RtvEEjaiQAoUZ+/IGKsGrVruA3N2UJISJR4nYqDwB7n19BXa3Xp0xkvs5b/vpPHPyICkI3GSdnc/ywPvTD0bSFAVQAqjAA4AFAc1UicrstKaTkNNSmk5DVxFLuaAxo70u5qolFjQ2NZY0Mmml6vVjNezQGTUCa8TUCaAUFSFRFTFMhFNTVqGKktIzCmphqCpqYNA2OpoyGlVNGRqSjaGmozSammI2oOH4zTSGkY2ppDUVUA651R7eH92B4jvpDEAhdslsdzsBVR0D4oIYRXT6tZbw5QuoDB4coMAZB32xjer28sY508ORcjfBGzKSMZBrQurdPktnZZFJV1VEeNI8PGG+UFthtjKnYbnfaiG6qpyMjcHcEcEVMVy3pXxXLav4KqJolVQqM+GV2HlCOB8udgMY75xTV98VXDqQJFQ8aIwFySRwfmIGRk539uKXae24fEfWFghdA2JmjbQF+ZcjGont6j6Vob9Wk5Msmed5H/51UyXwLFJGPnLEFjs2oksuezDJ/T7KvcrnB9dj6jtTkK1YXXUCzAnBZB5WZmyP8ZNVd8RIgVljYDAUEnb9aDOdR3yB6jil3h9JFP1Q1RFn6eFOQAPoTirD/pm8/wDF3G2w/fy7AfelvBkHcEfWgyMRtQGxdH+MLyGVGkuJZYlZTIjtr1p+YAtwce9dm6dfxXEYlhkDo3DD+hHIPsd6+cya8J2VhpZl0nxMqSCDgqDt33/Q1Nx2cr6UNKdRvo7eNpZnCoo3J5J7KB3J9K5J0j9oN7BgSEXSYxpk8rjHo4Gf5g1Udc+Jp76TVLhVUnw4xnQg4OB3PqTz7Dal2ns9174tuZrjxY5JLcptGivgIvvg4Ynvke3FdI+E+otdWiXDrpkfKyYUhSyEjUueVPI9M47GtF+Cvg9rhhdXKlbcbonBmI4+ie/eupaQoCqAqqAFUAAADgAdqdINzSsho8hpSVqIVAlak3NGlalXanE1CRqXc0R2pdzVEixqDGssaGxpkzqrGqoFqxmgJFqiWrBNQJoIIGpA0IGpBqrSRlNEFARqIDS0BRRAaAGqYNIDKaMjUupoimhcNo9HRqSQ0dGqaaxienI2qsjanYnpVUWCNWbm1jmjMcqB0YYIP9Qex96CjUyjVKnPuq/BFyjl7YiVNtILKjjbRuDgHACnOe1Qj+B74spPhLpBBzJtvzwD3xXS1NFU0bGnP4P2dSMcy3UagsWKpGX53x5iB+labcQ6JJUXJ8C4lg3AOoIxCn7gcfWu7Ka4jJhmnftJK8p7bl2P9DTxosULsSTz/PAqGT6sP9qizkZ7/UHGfqDn9KWZT2kx9Y8/rqqiSz9f51g1AA/xf7uP76iyj8xJHpQE0kDOsYyNZRS4xhdRAzv9c1vr/svul2Sa3IPJYyhmPqfKa52jE5bu2WGOw7V9MQS641cfnRW/mAf76nK6OOUf9Wt5n+0tv/ck/wDpVh8O/s58OTxL10kA3EUeoqxyMa2IGQMcDn6bHpDGhMaW6ekMADAAAAAAAwABwAKE5qbtS8j0EHI1JzPRpGpKV6qJoMjUq7UWRqVZqcSi5oTVlmqDNVFai1DY1l2obGhO3s17NQrOaY2zmo1g1EmgbKBqIGpXVUg1URoNU1elleiK1BGA9EVqWDVIPRoG1eiq9IB6IklTYez6vRkekFko6PS0uVYxvTkT1VxNT0LVNVFpE1NRmq+FqcjNTVQ4hoiml0NGU1KwurXXh20kn8Ebkf6xGF/UiuMhtnXBOcnA+bBO+B34rpvxxcabTR/nJEQ/QZY/8IrlUc3787DChlweNgTVYppCdcDIwV41L8o9j/CfY0t4gq4ktXfMkah+2Q/hSr7E4w4+tIPa3LHHhge7uhP301ZFdfpQJG1HQP8AaI/KP+dN3Fk67SyY1cJGME/Vu1LuAFIAwBjYfUUB6IZY7bAY7V9B/DNx4ljbvyTbxA/6wUKf1BrgVqnlLeua7J+ze419NVTzFJLH9s6h+jVORxtLGhs1ZY0F2qFIO9LO9TkalZGqkISPScr0SRqUkanCtClelnapytSrtVISZ6gXoLPQjJVyIo7NQy9CMlQL09ENrqJegl6xqoA5eol6AXrBagP/2Q==" alt="Image 1 description" class="img-fluid rounded-circle">
          <br><br> 
		  <p class="image-text">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Social Media</p>
			<p class="ser">AgroShop is active on social media, so you can follow us for the latest news and updates.
We share tips and advice on gardening and farming, as well as recipes and other interesting content.
You can also connect with other AgroShop customers on social media.</p>
		</div>
        </div>
    </div>
  </div>
  
  <br><br><br><br>
  <div class="container">
  <h2 class="line-title">Heighlights</h2>
    <div class="row">
	
      <div class="col-md-3">
        <div class="card">
          <img src="img1.png" class="card-img-top" alt="Card image 1">
		   <div class="item-desc">
        <h3>Tech frontier</h3>

      </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <img src="img2.png" class="card-img-top" alt="Card image 2">
		  <div class="item-desc">
        <h3>Vegetables & fruits</h3>
        
      </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <img src="img3.png" class="card-img-top" alt="Card image 3">
		   <div class="item-desc">
        <h3>Tools</h3>
        
      </div>
        </div>
      </div>
      <div class="col-md-3">
        <div class="card">
          <img src="img4.png" class="card-img-top" alt="Card image 4">
		   <div class="item-desc">
        <h3>Retail Rendezvous</h3>
        
      </div>
        </div>
      </div>
    </div>
  </div>
 <div id="agroshop-container">
    <i><b><p id="quote">"Connecting farmers with quality seeds and tools for a bountiful harvest."</p></b></i>

    <div class="circular-image-container">
      <img src="dipali.jpg" alt="Image 1" class="circular-image">
      <h2 style="font-size:15px;">Dipali Sawant</h2>
    </div>

    <div class="circular-image-container">
      <img src="kajal.jpg" alt="Image 2" class="circular-image">
      <h2 style="font-size:15px;">Kajal Shingavi</h2>
    </div>

    <div class="circular-image-container">
      <img src="img3.png" alt="Image 3" class="circular-image">
      <h2 style="font-size:15px;" >Apurva Talekar</h2>
    </div>
  </div>

  
   <div class="footer-section">
        <div class="footer-item">
            <h2>Company</h2>
            <p><a href=""> About Us</a></p>
            <p><a href=""> Contact Us</a></p>
            <p><a href=""> Our Services</a></p>
            <p><a href=""> Privacy Policy</a></p>
        </div>
        <div class="footer-item">
            <h2>Get Help </h2>
            <p><a href=""> FAQ</a></p>
            <p><a href=""> Shipping </a></p>
            <p><a href=""> Retuns </a></p>
            <p><a href=""> Payment Options </a></p>
        </div>
        <div class="footer-item">
            <h2>Online Shop</h2>
            <p><a href=""> Blogs </a></p>
            <p><a href=""> Watch </a></p>
            <p><a href=""> Shoes </a></p>
            <p><a href=""> Bress </a></p>
        </div>
        <div class="footer-item social">
            <h2> Follow Us </h2>
            <ul>
				<a href="http://www.instagram.com" class="fab fa-instagram"></a>
                <a href="http://www.youtube.com" class="fab fa-youtube"></a>
                <a href="http://www.facebook.com"class="fab fa-facebook"></a>
                <a href="http://www.linkedin.com"class="fab fa-linkedin"></a>
            </ul>
        </div>
    </div>

 
</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


  <script>
    $(document).ready(function () {
      $(".custom-carousel").owlCarousel({
  autoWidth: true,
 
});

      $(".custom-carousel .item").click(function () {
        $(".custom-carousel .item").not($(this)).removeClass("active");
        $(this).toggleClass("active");
      });
    });
  </script>

</body>
</html>
