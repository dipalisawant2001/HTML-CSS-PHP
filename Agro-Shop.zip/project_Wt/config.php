<?php

$conn = mysqli_connect('localhost','root','','agrodata') or die('connection failed');

?>