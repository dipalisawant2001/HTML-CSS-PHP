<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Share Your Feedback!</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
<style>  
  body {
  background-color: #f5f5f5;
  
}

.card {
  border-radius: 10px;
  box-shadow: 

</style> 
</head>
<body>

  <div class="container mt-5">
    <div class="card shadow-lg p-5 text-justify mx-auto" style="max-width: 500px;">
      <h2>Your Feedback Matters!</h2>
      <p class="mb-4">We'd love to hear your thoughts on your recent experience. Please take a moment to fill out this short survey.</p>

      <form action="survey_mail_send.php" method="post" enctype="multipart/form-data">
	  <div class="mb-3">
        <label for="name" class="form-label">Name:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
      </div>
        <div class="mb-3">
          <label for="email" class="form-label">Email Address:</label>
          <input type="text" class="form-control" id="email" name="email" placeholder="Enter your email">
        </div>
		<div class="mb-3">
        <label for="collegeName" class="form-label">College/Company Name:</label>
        <input type="text" class="form-control" id="collegeName" name="collegeName" placeholder="Enter your college name">
      </div>  
        <div class="mb-3">
          <label for="experience" class="form-label">How was your experience overall?</label>
          <select class="form-select" id="experience" required>
            <option value="">Please select an option</option>
            <option value="excellent">Excellent</option>
            <option value="good">Good</option>
            <option value="neutral">Neutral</option>
            <option value="poor">Poor</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="expectations" class="form-label">Are we meeting your expectations?</label>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="expectations" id="expectations-yes" value="yes">
            <label class="form-check-label" for="expectations-yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="expectations" id="expectations-no" value="no">
            <label class="form-check-label" for="expectations-no">No</label>
          </div>
        </div>
        <div class="mb-3">
          <label for="website" class="form-label">Did you find our website useful?</label>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="website" id="website-yes" value="yes">
            <label class="form-check-label" for="website-yes">Yes</label>
          </div>
          <div class="form-check form-check-inline">
            <input class="form-check-input" type="radio" name="website" id="website-no" value="no">
            <label class="form-check-label" for="website-no">No</label>
          </div>
        </div>
        <div class="mb-3">
          <label for="improvements" class="form-label">What can we improve?</label>
          <textarea class="form-control" id="improvements" rows="3" placeholder="Share your suggestions"></textarea>
        </div>
        <button type="submit" name="submit" class="btn btn-primary">Submit Feedback</button>
      </form>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="style.js"></script>
</body>
</html>
