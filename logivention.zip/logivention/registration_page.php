<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registration Form</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <style>
    body {
      display: flex;
      justify-content: center;
      align-items: center;
      min-height: 100vh;
      background-color: #f5f5f5;
    }

    .registration-form {
      background-color: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body>

  <div class="container registration-form">
    <h2 class="text-center mb-4">Registration Form</h2>
     <form action="register_mail_send.php" method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label for="name" class="form-label">Name:</label>
        <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
      </div>
      <div class="mb-3">
        <label for="email" class="form-label">Email ID:</label>
        <input type="text" class="form-control" id="email" name="email" placeholder="Enter your email">
      </div>
      <div class="mb-3">
        <label for="phone" class="form-label">Phone Number:</label>
        <input type="tel" class="form-control" id="phone" name="phone" placeholder="Enter your phone number">
      </div>
      <div class="mb-3">
        <label for="dob" class="form-label">Date of Birth:</label>
        <input type="date" class="form-control" id="dob" name="dob">
      </div>
	   <div class="mb-3">
        <label for="gender">Gender:</label>
        <select class="form-select" id="gender" name="gender">
          <option value="" name="gender">Select Gender</option>
          <option value="male" name="gender">Male</option>
          <option value="female" name="gender">Female</option>
          <option value="other" name="gender">Other</option>
        </select>
      </div>
      <div class="mb-3">
        <label for="collegeName" class="form-label">College/Company Name:</label>
        <input type="text" class="form-control" id="collegeName" name="collegeName" placeholder="Enter your college name">
      </div>  
	   <div class="mb-3">
        <label for="collegeIdFile">College/Company ID File:</label>
        <input type="file" class="form-control" id="collegeIdFile" name="collegeIdFile">
      </div>
	  <div class="mb-3 form-check form-switch">
                <input class="form-check-input" type="checkbox" id="sendDetails" name="sendDetails">
                <label class="form-check-label" for="sendDetails">Send copy of registration details into email</label>
      </div>
      <button type="submit" name="submit" value="submit" class="btn btn-primary btn-block">Register</button>
    </form>
  </div>

</body>
</html>
