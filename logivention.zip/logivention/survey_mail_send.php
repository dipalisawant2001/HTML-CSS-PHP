<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $com_nm = $_POST['collegeName'];
    $nm = $_POST['name'];

    $host = "localhost:3306";
    $user1 = "root";
    $pass1 = "";
    $dbnm = "logivention_database";

    $conn = mysqli_connect($host, $user1, $pass1, $dbnm) or die(mysqli_error());

    // Retrieve company address and logo name from database
    $query = "SELECT com_address, com_logo FROM survey_setting WHERE com_nm='$com_nm'";
    $result = mysqli_query($conn, $query) or die(mysqli_error($conn));

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $companyAddress = $row['com_address'];
        $companyLogoName = $row['com_logo'];

        // Add ".png" extension to the logo name
        $companyLogoNameWithExtension = $companyLogoName . '.png';

        // Construct the local image path using the logo name
        $localImagePath = 'survey_images/' . $companyLogoNameWithExtension; // Adjust the path as needed

        // Read the image and convert it to base64 if the file exists
        if (file_exists($localImagePath)) {
            $companyLogoBase64 = base64_encode(file_get_contents($localImagePath));

            $mail = new PHPMailer(true);

            try {
                // Configure PHPMailer
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com';
                $mail->SMTPAuth   = true;
                $mail->Username   = 'dipali.sawant_comp22@pccoer.in';
                $mail->Password   = 'rdjlhplhdrkasgou';
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                // Recipient and sender information
                $mail->setFrom('dipali.sawant_comp22@pccoer.in');

                foreach (explode(',', $email) as $EmailAddress) {
                    $mail->addAddress(trim($EmailAddress));
                }

                $mail->addReplyTo('dipali.sawant_comp22@pccoer.in', 'Information');

                // Email content
                $mail->isHTML(true);
                $mail->Subject = "Thank you for your quality time";
                $mail->Body = '
                    <div style="background-color:lightseagreen; padding: 5px;">
                        <nav class="navbar navbar-light">
                            <a class="navbar-brand" href="https://www.logivention.com/">
                                <img src="cid:companyLogo" alt="Company Logo" class="contain" width="200" height="150" style="object-fit: contain; margin-right:0px;">
                            </a>
                        </nav>
                    </div>
                    <p>Dear ' . $nm . '</p>
					<p>Thank you for visiting us. You filled survey form successfully</p>
					<p>Visit us again</p>
					<p>Happy journey...</p>
					<p>Regards,</p>
                ';


                $mail->Body .= '
                    <div style="background-color: lightseagreen; color: white; padding: 15px;">
                        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
                        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
                        <div class="text-center">
                            <a href="https://www.linkedin.com/in/" class="btn btn-link">
                                <i class="fab fa-linkedin"></i>
                            </a>
                            <a href="https://api.whatsapp.com/send?phone=" class="btn btn-link">
                                <i class="fab fa-whatsapp"></i>
                            </a>
                            <a href="https://www.facebook.com/" class="btn btn-link">
                                <i class="fab fa-facebook-f"></i>
                            </a>
                            <a href="https://www.instagram.com/" class="btn btn-link">
                                <i class="fab fa-instagram"></i>
                            </a>
                        </div>
                        <p style="margin-top: 10px; text-align:center; color:white; font-weight: bold;">' . $companyAddress . '</p>
                    </div>
                ';

                // Attach the image to the email
                $mail->addEmbeddedImage($localImagePath, 'companyLogo');

                // Send email
                if (!$mail->send()) {
                    echo 'Mailer Error: ' . $mail->ErrorInfo;
                } else {
                    echo 'Email sent successfully!';
                }
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            // Provide a default image source or handle this case as needed
            $companyLogoBase64 = 'https://png.pngtree.com/png-vector/20210708/ourmid/pngtree-you-are-welcome-lettering-design-vector-png-image_3554080.jpg'; // Adjust the default image path
        }
    } else {
        $companyAddress = "Address not found";
        $headerContent = ""; // Ensure headerContent is not empty even without a logo
    }
}
?>
