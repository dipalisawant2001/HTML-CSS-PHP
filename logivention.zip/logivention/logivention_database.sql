-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 18, 2024 at 10:07 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `logivention_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `register_setting`
--

CREATE TABLE `register_setting` (
  `com_name` varchar(255) NOT NULL,
  `com_logo` varchar(255) NOT NULL,
  `com_address` varchar(255) NOT NULL,
  `com_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `register_setting`
--

INSERT INTO `register_setting` (`com_name`, `com_logo`, `com_address`, `com_email`) VALUES
('Facebook ', 'facebook', 'Facebook Headquarters 1 Hacker Way Menlo Park, CA 94025', 'facebook@gmail.com'),
('Pimpri chinchwad college of engineering and research,Ravet', 'pccoer', 'Plot No. B, Sector no. 110, Gate no.1, Laxminagar, Ravet, Haveli, Pune - 412101. ; Phone. 8237238080 ; Email. pccoer.ravet@gmail.com', 'pccoer.ravet@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `survey_setting`
--

CREATE TABLE `survey_setting` (
  `com_nm` varchar(255) NOT NULL,
  `com_logo` varchar(255) NOT NULL,
  `com_address` varchar(255) NOT NULL,
  `com_email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `survey_setting`
--

INSERT INTO `survey_setting` (`com_nm`, `com_logo`, `com_address`, `com_email`) VALUES
('Facebook ', 'facebook ', 'Facebook Headquarters 1 Hacker Way Menlo Park, CA 94025', 'facebook@gmail.com'),
('Google', 'google', '2 P&G Plaza. Cincinnati, Ohio 45202, US · 2nd Floor, 110 Church Street. Melbourne, Victoria 3122, AU · Level 4, 1 Innovation Road, Macquarie Park', 'google@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register_setting`
--
ALTER TABLE `register_setting`
  ADD PRIMARY KEY (`com_name`);

--
-- Indexes for table `survey_setting`
--
ALTER TABLE `survey_setting`
  ADD PRIMARY KEY (`com_nm`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
