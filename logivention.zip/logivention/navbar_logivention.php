<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Email Settings</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <style>
body {
  background-image: url('back.png');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
}
</style>	
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">  <div class="container-fluid">
    <a class="navbar-brand" href="https://www.logivention.com/">
      <img src="https://www.logivention.com/img/LOGIVENTION_LOGO_NAME_WHITE.png" alt="Company Logo" width="250" height="60" alt="">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
       <ul class="navbar-nav ms-auto me-auto"> 
				<li class="nav-item mx-3"> 
					<a class="nav-link" href="navbar_logivention.php">Home</a>
                </li>
				<li class="nav-item mx-3"> 
					<a class="nav-link" href="?page=registration_page">Fill Registration Form</a>
                </li>
                <li class="nav-item mx-3">
                    <a class="nav-link" href="?page=survey_form">Fill Survey Form</a>
                </li>
                <li class="nav-item mx-3">
                    <a class="nav-link" href="?page=registration_setting">Registration Email Settings</a>
                </li>
                <li class="nav-item mx-3">
                    <a class="nav-link" href="?page=survey_setting">Survey Email Settings</a>
                </li>
            </ul>
    </div>
  </div>
</nav>

<div class="container mt-5"> <?php
    if (isset($_GET['page'])) {
      $page = $_GET['page'];
      include $page . '.php';
    }
  ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
