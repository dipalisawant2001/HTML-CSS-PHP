<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Survey Email Settings</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container mt-5">
        <div class="card shadow-lg p-5 mx-auto" style="max-width: 500px;">
            <h2 class="text-center">Survey Email Settings</h2>
            <p class="mb-4">Please provide the following information for survey emails:</p>

            <form action="" method="post" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="college_name" class="form-label">Institude/Company Name:</label>
                    <input type="text" class="form-control" id="college_name" name="college_name" required>
                </div>
				<div class="mb-3">
                    <label for="college_logo_name" class="form-label">Institude/Company logo Name:</label>
                    <input type="text" class="form-control" id="college_logo_name" name="college_logo_name" required>
                </div>
                <div class="mb-3">
                    <label for="college_logo" class="form-label">College/Company Logo:</label>
                     <input type="file" class="form-control" id="college_logo" name="college_logo">
                </div>
                <div class="mb-3">
                    <label for="college_address" class="form-label">College/Company Address:</label>
                    <textarea class="form-control" id="college_address" name="college_address" rows="3"></textarea>
                </div>
                <div class="mb-3">
                    <label for="college_email" class="form-label">College/Company Email:</label>
                    <input type="email" class="form-control" id="college_email" name="college_email" required>
                </div>
                <button type="submit" class="btn btn-primary" name="submit">Save Settings</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
	

<?php
if (isset($_POST["submit"])) {

				$col_nm = $_POST['college_name'];
				$col_logo_name = $_POST['college_logo_name'];
				$col_add = $_POST['college_address'];
				$col_mail = $_POST['college_email'];
				
			if(isset($_FILES['college_logo']) && $_FILES['college_logo']['error'] == 0) {
			$file = $_FILES['college_logo'];
			$fileName = $file['name'];
			$fileTmpName = $file['tmp_name'];
			$fileType = $file['type'];

			// Check file type
			$allowedTypes = array('image/png');
			if (!in_array($fileType, $allowedTypes)) {
			  echo '<script>alert("Invalid image type. Please select a PNG")</script>';
			  exit();
			}

			// Create the images folder if it doesn't exist
			$imagesFolder = 'survey_images/'; // Adjust the path if needed
			if (!file_exists($imagesFolder)) {
			  mkdir($imagesFolder, 0755, true); // Create with appropriate permissions
			}

			// Move the uploaded image to the images folder
			$targetFilePath = $imagesFolder . $fileName;
			if (move_uploaded_file($fileTmpName, $targetFilePath)) {

			  // Store the image path in the database instead of base64 data
			  $imagePath = $targetFilePath; // Store relative path or full path as needed

			  $host = "localhost:3306";
				$user1 = "root";
				$pass1 = "";
				$dbnm = "logivention_database";
				$conn = mysqli_connect($host, $user1, $pass1, $dbnm) or die(mysqli_error());

				// Check if college name already exists
				$checkQuery = "SELECT * FROM `survey_setting` WHERE `com_nm` = '$col_nm'";
				$result = mysqli_query($conn, $checkQuery);

				if (mysqli_num_rows($result) > 0) {
					// College name exists, use UPDATE query
					$query = "UPDATE `survey_setting` SET `com_logo` = '$col_logo_name', `com_address` = '$col_add', `com_email` = '$col_mail' WHERE `com_nm` = '$col_nm'";
					if (mysqli_query($conn, $query)) {
						echo '<script>alert("Data updated successfully...")</script>';
					} else {
						echo '<script>alert("Failed to update data")</script>';
					}
				} else {
					// College name doesn't exist, use INSERT query
					$query = "INSERT INTO `survey_setting`(`com_nm`, `com_logo`, `com_address`, `com_email`) VALUES ('$col_nm','$col_logo_name','$col_add','$col_mail')";
					if (mysqli_query($conn, $query)) {
						echo '<script>alert("Data stored successfully...")</script>';
					} else {
						echo '<script>alert("Failed to insert data")</script>';
					}
				}

			} else {
			  echo '<script>alert("Error uploading image")</script>';
			}
		  } else {
			echo '<script>alert("Image upload failed")</script>';
		  }
		}
?>
</body>
</html>
